/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package prooofconceptrepresentacionbinaria;

import binario.EvolutionBits;
import binario.util.BitsOperation;
import binario.util.TruncarDecimal;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import jppf.tareas.GenerarPoblacion;
import jppf.tareas.Poblacion;
import org.jppf.JPPFException;
import org.jppf.client.JPPFClient;
import org.jppf.client.JPPFJob;
import org.jppf.server.protocol.JPPFTask;

/**
 *
 * @author servkey
 */
public class Main {

    	private static JPPFClient jppfClient = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, JPPFException {

        try{
            int tarea1 = 50;
            int tarea2 = 30;
            int tarea3 = 20;
            int genotipo[][] = null;

            jppfClient = new JPPFClient();
            JPPFJob job = new JPPFJob();

            job.setId("initPopulation");
            job.addTask(new GenerarPoblacion(0.3f,tarea1));
            job.addTask(new GenerarPoblacion(.23f,tarea2));
            job.addTask(new GenerarPoblacion(.53f,tarea3));
            job.setBlocking(true);
            Poblacion poblacion = null;
            try {
                System.out.println("Lanzando inicio de poblacion....");
                List<JPPFTask> results = jppfClient.submit(job);
                List<Poblacion> poblaciones = new ArrayList<Poblacion>();

                for (int i=0; i<results.size(); i++)
                {
                    System.out.println("Obteniendo resultados");
                    JPPFTask matrixTask = results.get(i);

                    if (matrixTask.getException() != null) throw matrixTask.getException();
                        poblacion = (jppf.tareas.Poblacion) matrixTask.getResult();
                        poblaciones.add(poblacion);
                    if (poblacion != null){
                         System.out.println("Poblacion generada exitosamente");
                         binario.util.BitsOperation.imprimirPoblacion(poblacion.getGenotipo());
                    }
                     else
                            System.out.println("Poblacion no generadaaa!!");

                }

                //Juntar individuos
                genotipo = new int[tarea1+tarea2+tarea3][poblacion.getGenotipo()[0].length];
                int indexGlobal = 0;
                for (int index = 0;  index < poblaciones.size(); index++){
                     Poblacion tmp = poblaciones.get(index);
                     for (int index0 = 0; index0 < tmp.getGenotipo().length; index0++)
                       genotipo[indexGlobal++] = tmp.getGenotipo()[index0];
                }
            
            } catch (Exception ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }finally
		{
			//if (jppfClient != null) jppfClient.close();
		}

            System.out.println("Termino de generar poblacion");

            System.out.println("Genotipo completo ---- >");
            //Imprimiendo genotipo
            binario.util.BitsOperation.imprimirPoblacion(genotipo);
            EvolutionBits eb = new EvolutionBits(.3f,genotipo,jppfClient);
            eb.start();
        }
    catch(Exception e)
   {
        System.out.println("Intente la ejecución nuevamente, el servidor no funciona");
    }
  }

}
