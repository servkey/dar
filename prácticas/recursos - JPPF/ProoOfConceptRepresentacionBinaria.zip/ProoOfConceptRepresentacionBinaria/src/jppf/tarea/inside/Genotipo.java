/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jppf.tarea.inside;

import org.jppf.client.JPPFJob;

/**
 *
 * @author servkey
 */
public class Genotipo {

}
