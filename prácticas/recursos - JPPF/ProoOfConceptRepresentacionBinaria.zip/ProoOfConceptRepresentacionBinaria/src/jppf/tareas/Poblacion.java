/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jppf.tareas;
import binario.util.Random;
import binario.util.*;
import java.io.Serializable;
/**
 *
 * @author servkey
 */
public class Poblacion implements Serializable{
    private float[][] poblacion;
    private int poblacionTamano = 200;
    private float semilla = .2f;
    private float linf = -10f;
    private float lsup = 10f;
    private int individuoTamano = 10;
    private int MAXGEN = 1250;
    //private int evaluaciones = 0;
    private int longitudCadena = 0;
    private int precision = 2;

    //Para representación binaria
    private int genotipo[][];


    public Poblacion(float semilla, int tamano){
        Random.setRseed(semilla);
        this.poblacionTamano = tamano;
        longitudCadena = BitsOperation.calculateLongitudCadena(linf, lsup, precision);
        poblacion = new float[this.poblacionTamano][this.individuoTamano];

        genotipo = iniciarPoblacion(this.getPoblacionTamano(),longitudCadena * this.individuoTamano);
        poblacion = this.poblacionToFenotipo(genotipo);
   }



    private int[] generarIndividuo(){
        int[] individuo = new int[this.longitudCadena * this.individuoTamano];
        for (int i = 0; i < individuo.length; i++)
            individuo[i] = Random.rnd(0, 1);
        return individuo;
    }


    public int[][] iniciarPoblacion(int filas, int columnas){
        Random.randomize();
        int[][] genotipo = new int [filas][columnas];
        int i = 0;

        while (i < getPoblacionTamano()){
                genotipo[i] =  generarIndividuo();
                i++;
         }
         //poblacion = poblacionToFenotipo(genotipo);
         return genotipo;
   }

   private float[][] poblacionToFenotipo(int [][] genotipo){
       float[][] poblacion = new float[this.getPoblacionTamano()][this.individuoTamano];
        for (int index0 = 0; index0 < genotipo.length; index0++)
            poblacion[index0] = this.GenotipoToFenotipo(genotipo[index0]);
        return poblacion;
   }

   public int[][] getPoblacion(){
       return genotipo;
   }

   private float[] GenotipoToFenotipo(int[] genotipo){
        float[] fenotipo = new float[this.individuoTamano];
        int indexGenotipo = 0;
        int[] individuoGenotipo = new int[longitudCadena];

        for(int index = 0; index < this.individuoTamano; index++){
                System.arraycopy(genotipo, indexGenotipo, individuoGenotipo, 0, longitudCadena);
                indexGenotipo = index * this.longitudCadena;
                fenotipo[index] = TruncarDecimal.truncate(BitsOperation.codificacion(individuoGenotipo, linf, lsup));
                //fenotipo[index] = BitsOperation.codificacion(individuoGenotipo, linf, lsup);
        }
        return fenotipo;
    }

    /**
     * @return the poblacionTamano
     */
    public int getPoblacionTamano() {
        return poblacionTamano;
    }

    /**
     * @param poblacionTamano the poblacionTamano to set
     */
    public void setPoblacionTamano(int poblacionTamano) {
        this.poblacionTamano = poblacionTamano;
    }

    /**
     * @return the semilla
     */
    public float getSemilla() {
        return semilla;
    }

    /**
     * @param semilla the semilla to set
     */
    public void setSemilla(float semilla) {
        this.semilla = semilla;
    }

    /**
     * @return the MAXGEN
     */
    public int getMAXGEN() {
        return MAXGEN;
    }

    /**
     * @param MAXGEN the MAXGEN to set
     */
    public void setMAXGEN(int MAXGEN) {
        this.MAXGEN = MAXGEN;
    }


    public int[][] getGenotipo(){
        return genotipo;
    }

}
