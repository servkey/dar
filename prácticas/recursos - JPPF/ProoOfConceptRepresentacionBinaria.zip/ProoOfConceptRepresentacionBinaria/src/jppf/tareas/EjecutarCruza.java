/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jppf.tareas;

import binario.util.BitsOperation;
import binario.util.Random;
import org.jppf.server.protocol.JPPFTask;

/**
 *
 * @author servkey
 */
public class EjecutarCruza  extends JPPFTask{
    private int[][] hijos;
    private int tamano;
    private int longitudCadena;
    private int individuoTamano;
    private int[][] padres1;
    private int[][] padres2;
    private float probCruza;

    public EjecutarCruza(int tamano, int longitudCadena, int individuoTamano, float probCruza, int [][] padres1, int [][] padres2){
        
        this.longitudCadena = longitudCadena;
        this.tamano = tamano;
        this.individuoTamano = individuoTamano;
        this.probCruza = probCruza;
        this.padres1 = padres1;
        this.padres2 = padres2;
    }

    public void cruza(){
        hijos = new int[tamano][longitudCadena * individuoTamano];
        int indexHijo1 = 0;
        int indexHijo2 = indexHijo1 + 1;
        for (int index = 0; index < padres1.length; index++){
            hijos[indexHijo1] = padres1[index];
            hijos[indexHijo2] = padres2[index];

            //Si probabilidad es 1 entonces aplica cruza de dos puntos
            if (Random.flip(this.probCruza) == 1){
                int ktmp0 =  Random.rnd(0, (this.longitudCadena * 10) - 1);
                int ktmp1 =  BitsOperation.generarAleatorioDiferente(ktmp0,0, (this.longitudCadena * 10) - 1);
                int k1,k2;

                if (ktmp0 > ktmp1){
                    k1 = ktmp1;
                    k2 = ktmp0;
                }else{
                    k1 = ktmp0;
                    k2 = ktmp1;
                }
                for (int ik = k1; ik <= k2;ik++){

                    //intercambio
                    int aux1 = hijos[indexHijo1][ik];
                    int aux2 = hijos[indexHijo2][ik];
                    hijos[indexHijo1][ik] = aux2;
                    hijos[indexHijo2][ik] = aux1;
                }
            }
            indexHijo1 += 2;
            indexHijo2 = indexHijo1 + 1;
        }

    }

    public void run() {
        try
	 {
            System.out.println("Realizando cruza!!");          
             cruza();
             setResult(hijos);
         }
         catch(Exception e)
         {
             setException(e);
         }
    }


}
