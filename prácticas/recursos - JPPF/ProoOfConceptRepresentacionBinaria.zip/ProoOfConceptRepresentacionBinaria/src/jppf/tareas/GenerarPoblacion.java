/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jppf.tareas;

import org.jppf.server.protocol.JPPFTask;

/**
 *
 * @author servkey
 */
public class GenerarPoblacion extends JPPFTask{
    private Poblacion poblacion;
    private float semilla;
    private int tamano;
    public GenerarPoblacion(float semilla, int tamano){
        this.semilla = semilla;
        this.tamano = tamano;
    }

    public void run() {
         try
	 {
             System.out.println("Generando poblacion.....");
             System.out.println("Semilla: "  +  semilla);
             System.out.println("Tamaño de poblacion a generar: "  +  tamano);

             poblacion = new Poblacion(semilla, tamano);

             setResult(poblacion);
         }
         catch(Exception e)
         {
                    setException(e);
         }

    }

}
