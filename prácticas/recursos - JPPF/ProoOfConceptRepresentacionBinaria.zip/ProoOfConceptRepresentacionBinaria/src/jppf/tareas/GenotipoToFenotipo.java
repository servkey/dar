/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jppf.tareas;

import binario.util.BitsOperation;
import binario.util.TruncarDecimal;
import org.jppf.server.protocol.JPPFTask;

/**
 *
 * @author servkey
 */
public class GenotipoToFenotipo  extends JPPFTask{
   private int genotipo[];
   private int individuoTamano;
   private int longitudCadena;
   private float linf;
   private float lsup;

   public GenotipoToFenotipo(int[] genotipo, int individuoTamano, int longitudCadena, float linf, float lsup){
        this.genotipo = genotipo;
        this.individuoTamano = individuoTamano;
        this.longitudCadena = longitudCadena;
        this.linf = linf;
        this.lsup = lsup;
   }

   public float[] GenotipoToFenotipo(){
        float[] fenotipo = new float[this.individuoTamano];
        int indexGenotipo = 0;
        int[] individuoGenotipo = new int[this.longitudCadena];
        for(int index = 0; index < this.individuoTamano; index++){
                System.arraycopy(genotipo, indexGenotipo, individuoGenotipo, 0, longitudCadena);
                indexGenotipo = index * this.longitudCadena;
                fenotipo[index] = TruncarDecimal.truncate(BitsOperation.codificacion(individuoGenotipo, linf, lsup));                
        }
        return fenotipo;
    }

    public void run() {
        //Traducir genotipo
        System.out.println("Traduciendo genotipo a fenotipo...");
        setResult(this.GenotipoToFenotipo());
    }
}
